package com.example.crosslaufprojekt;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, ConnectDialog.ConnectDialogListener, AttentionDialog.AttentionDialogListener {

    //Für die logische Schaltung des "Navigation Drawers"
    private DrawerLayout drawer;

    //Client für das Netzwerk zur Übermittlung der Daten vom Android-Gerät zum PC
    //private ClientNetwork cn = new ClientNetwork("192.168.178.61", 8001);






    private String ip;
    private int port;
    private String message;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        //StrictMode.setThreadPolicy(policy);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (androidx.appcompat.widget.Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        if(savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new ScannerFragment()).commit();
            navigationView.setCheckedItem(R.id.nav_scanner);
        }
        SharedPreferences sharedPreferences = getSharedPreferences("SPFile", 0);

        ip = sharedPreferences.getString("IP", "192.168.178.61");
        port = sharedPreferences.getInt("Port", 8000);



    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.nav_scanner:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new ScannerFragment()).commit();
                break;
            case R.id.nav_stopwatch:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new StopwatchFragment()).commit();
                break;
            case R.id.nav_help:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HelpFragment()).commit();
                break;
            case R.id.nav_connect:
                //Toast.makeText(this, "Connect", Toast.LENGTH_SHORT).show();
                openConnectDialog();
                break;
            case R.id.nav_close_connection:
                openAttentionDialog();
        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }



    public void scanStarten(View view){
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.initiateScan();
    }

    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        IntentResult scanResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent);
        if (scanResult != null) {

            String barcode = scanResult.getContents();
            String typ = scanResult.getFormatName();


            EditText etBarcode = (EditText) findViewById(R.id.etBarcode);
            EditText etTyp = (EditText) findViewById(R.id.etTyp);

            etBarcode.setText(barcode);
            //cn.execute("B"+barcode);

            //cn.sendMessage("B" + barcode);
            sendMessage("B"+barcode);
            etTyp.setText(typ);
        }
    }

    public void serverVerbindungBeenden() {
        //cn.execute("A");
        //cn.sendMessage("A");
        sendMessage("A");
    }


    public void sendMessage(String msg){
        message = msg;
        new AndroidClient().execute();
    }



    private class AndroidClient extends AsyncTask<Void, Void, Void>{
        InetSocketAddress address = new InetSocketAddress(ip, port);
        String msg = message;
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                System.out.println("[Client] Verbinde zu Server...");
                Socket socket = new Socket();
                System.out.println("[Client] Socket erstellt.");
                socket.connect(address);
                System.out.println("[Client] Client verbunden.");

                System.out.println("[Client] Sende Nachricht...");
                PrintWriter pw = new PrintWriter(new PrintWriter(new OutputStreamWriter(socket.getOutputStream())));
                pw.println(msg);
                pw.flush();
                System.out.println("[Client] Nachricht gesendet.");

            /*Scanner s = new Scanner(new BufferedReader(new InputStreamReader(socket.getInputStream())));
            if(s.hasNextLine()) {
                System.out.println("[Client] Nachricht vom Server: "+ s.nextLine());
            }*/

                //Verbindung schließen
                pw.close();
                //s.close();
                socket.close();

            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
    }

    public void openConnectDialog(){
        ConnectDialog connectDialog = new ConnectDialog();
        connectDialog.show(getSupportFragmentManager(), "connect dialog");
    }

    @Override
    public void applyTexts(String tempIp, int tempPort) {
       this.ip = tempIp;
       this.port = tempPort;

        SharedPreferences sharedPreferences = getSharedPreferences("SPFile", 0);

        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString("IP", ip);
        editor.putInt("Port", port);

        editor.commit();

       System.out.println("IP: "+ this.ip+" Port: "+ this.port);

    }

    public void openAttentionDialog(){
        AttentionDialog dialog = new AttentionDialog("closeConnection");
        dialog.show(getSupportFragmentManager(), "attentionDialogStopConnection");

    }
    @Override
    public void onWeiterClicked() {

        serverVerbindungBeenden();
    }
    @Override
    public void onResetClicked(){
        StopwatchFragment stopwatchFragment = (StopwatchFragment) getSupportFragmentManager().findFragmentById(R.id.fragment_container);
        stopwatchFragment.resetChronometer();
    }
}
