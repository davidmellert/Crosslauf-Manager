package com.example.crosslaufprojekt;

import android.os.Bundle;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class StopwatchFragment extends Fragment{

    //Für die Logik der Stoppuhr
    private Chronometer chronometer;
    private boolean isRunning;
    private long pauseOffset;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_stopwatch, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        chronometer = view.findViewById(R.id.chronometer);
        isRunning = false;


        Button startStopButton = view.findViewById(R.id.startstopButton);
        ImageView addPersonButton = view.findViewById(R.id.addPersonButton);
        Button resetButton = view.findViewById(R.id.resetButton);

        startStopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startstopChronometer();
            }
        });

        addPersonButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addPerson();
            }
        });

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAttentionDialog();
            }
        });



    }
    public void startstopChronometer(){
        if(!isRunning){
            chronometer.setBase(SystemClock.elapsedRealtime()-pauseOffset);
            chronometer.start();
            isRunning = true;
        }else{
            chronometer.stop();
            pauseOffset = SystemClock.elapsedRealtime()-chronometer.getBase();
            isRunning = false;

        }
    }

    public void resetChronometer(){
        chronometer.setBase(SystemClock.elapsedRealtime());
        pauseOffset = 0;
    }

    public void addPerson() {

        String time = String.valueOf(SystemClock.elapsedRealtime() - chronometer.getBase());
        MainActivity mainActivity = (MainActivity)getActivity();
        if(isRunning) {
            mainActivity.sendMessage("C" + time);
            Toast.makeText(mainActivity, time, Toast.LENGTH_SHORT);
        }else{
            Toast.makeText(mainActivity, "Stoppuhr pausiert!", Toast.LENGTH_SHORT );
        }

    }
    public void openAttentionDialog(){
        MainActivity mainActivity = (MainActivity)getActivity();
        AttentionDialog dialog = new AttentionDialog("resetChronometer");
        dialog.show(mainActivity.getSupportFragmentManager(), "attention dialog reset");
    }


}
