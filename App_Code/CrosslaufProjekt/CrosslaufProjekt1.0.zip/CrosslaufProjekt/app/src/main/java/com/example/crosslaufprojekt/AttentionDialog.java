package com.example.crosslaufprojekt;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class AttentionDialog extends DialogFragment {

    private String usage;
    private AttentionDialogListener listener;

    public AttentionDialog(String usage){
        this.usage = usage;
    }
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        if(usage == "resetChronometer"){
            builder.setTitle("Achtung!")
                    .setMessage("Bist du dir sicher, dass du die Zeit zurücksetzen willst?")
                    .setNegativeButton("Abbrechen", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    }).setPositiveButton("Reset", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    listener.onResetClicked();
                }
            });
        }else if(usage == "closeConnection") {
            builder.setTitle("Achtung!")
                    .setMessage("Bist du dir sicher, dass du die Verbindung trennen willst? " +
                            "Die App funktioniert erst wieder, wenn das Programm auf dem PC gestartet wird.")
                    .setNegativeButton("Abbrechen", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    }).setPositiveButton("Weiter", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    listener.onWeiterClicked();
                }
            });
        }
        return builder.create();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        try {
            listener = (AttentionDialogListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()+" must implement AttentionDialogListener");
        }
    }

    public interface AttentionDialogListener{
        void onWeiterClicked();
        void onResetClicked();
    }
}
